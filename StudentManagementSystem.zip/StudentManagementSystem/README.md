# Student Management System (C Project)

This project is a menu-driven Student Management System written in C.  
It supports Admin, Staff, and Guest roles with separate permissions.

## Features
### 👑 Admin
- Add Student  
- Display Students  
- Search  
- Update  
- Delete  
- Sort (Roll, Name, Marks)  
- Add User  
- Change Password  

### 👨‍🏫 Staff
- Add  
- Display  
- Search  
- Update  

### 👀 Guest
- Display  
- Search  

## Files Included
- `student_manager.c` — Main C Source Code  
- `students.txt` — Student Records  
- `credentials.txt` — Login Credentials  

## How to Run
```
gcc student_manager.c -o sms
./sms
```

Enjoy your project! 🚀
